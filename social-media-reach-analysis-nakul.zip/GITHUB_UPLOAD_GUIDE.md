# GitHub Upload

1. Open the `social-media-reach-analysis` repository.
2. Click **Add file** → **Upload files**.
3. Upload the contents of this folder.
4. Enter commit message: `Add complete Social Media Reach Analysis project`.
5. Click **Commit changes**.
