import pandas as pd

df = pd.read_csv('data/social_media_reach_cleaned.csv', parse_dates=['Date'])
print('\n--- Platform Reach ---')
print(df.groupby('Platform')['Reach'].sum().sort_values(ascending=False))
print('\n--- Content Engagement ---')
print(df.groupby('Content Type')['Engagements'].mean().sort_values(ascending=False))
print('\n--- Overall KPIs ---')
print('Total Reach:', int(df['Reach'].sum()))
print('Total Impressions:', int(df['Impressions'].sum()))
print('Total Engagements:', int(df['Engagements'].sum()))
print('Average Engagement Rate:', round(df['Engagement Rate (%)'].mean(),2), '%')
