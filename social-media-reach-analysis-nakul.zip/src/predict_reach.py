import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score

df=pd.read_csv('data/social_media_reach_cleaned.csv')
X=df[['Platform','Content Type','Impressions','Engagements','Ad Spend (INR)']]
y=df['Reach']
pre=ColumnTransformer([('cat',OneHotEncoder(handle_unknown='ignore'),['Platform','Content Type'])],remainder='passthrough')
model=Pipeline([('pre',pre),('rf',RandomForestRegressor(n_estimators=200,random_state=42))])
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42)
model.fit(Xtr,ytr); pred=model.predict(Xte)
print('MAE:',round(mean_absolute_error(yte,pred),2)); print('R2:',round(r2_score(yte,pred),3))
