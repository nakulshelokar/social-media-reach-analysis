import streamlit as st
import pandas as pd
import plotly.express as px
st.set_page_config(page_title='Social Media Reach Analysis',layout='wide')
df=pd.read_csv('data/social_media_reach_cleaned.csv',parse_dates=['Date'])
st.title('Social Media Reach Analysis')
for c,v in zip(st.columns(4),[df.Reach.sum(),df.Impressions.sum(),df.Engagements.sum(),df['Engagement Rate (%)'].mean()]):
    c.metric(['Total Reach','Total Impressions','Total Engagements','Avg Engagement Rate (%)'][[df.Reach.sum(),df.Impressions.sum(),df.Engagements.sum(),df['Engagement Rate (%)'].mean()].index(v)],round(v,2) if isinstance(v,float) else int(v))
st.plotly_chart(px.bar(df.groupby('Platform',as_index=False)['Reach'].sum(),x='Platform',y='Reach',title='Reach by Platform'),use_container_width=True)
st.plotly_chart(px.line(df.groupby(df.Date.dt.to_period('M').astype(str),as_index=False)['Reach'].sum(),x='Date',y='Reach',title='Monthly Reach Trend'),use_container_width=True)
