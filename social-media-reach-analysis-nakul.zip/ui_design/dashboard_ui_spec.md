# Dashboard UI Specification

- Header: Social Media Reach Analysis
- KPI cards: Reach, Impressions, Engagements, Engagement Rate
- Filters: Platform, Content Type, Date
- Charts: Reach by Platform, Engagement by Content Type, Monthly Trend, Impressions vs Engagements
- Style: clean modern analytics dashboard with blue/cyan accents
