# Social Media Reach Analysis — Final Report

## Objective
Analyze social media performance and identify patterns in reach and engagement.

## Data Preparation
Raw data contains intentionally missing numeric values. Missing numeric values are replaced with their median values in the cleaned dataset.

## Analysis
The project compares platforms, content types and monthly trends using Python visualizations and a Power BI-ready Excel dataset.

## Machine Learning
A Random Forest regression model is trained to estimate reach from platform, content type, impressions, engagements and ad spend.

## Conclusion
The project demonstrates an end-to-end analytics workflow from data preparation through visualization, dashboarding and predictive modeling.
