# Research Material

This project studies social media reach, impressions, engagement, clicks, ad spend and conversions. The dataset is synthetic and intended for portfolio/learning use.

Key questions:
- Which platforms generate the most reach?
- Which content types generate higher engagement?
- How does reach change over time?
- How are impressions related to engagement?
- Can basic machine learning estimate reach?
