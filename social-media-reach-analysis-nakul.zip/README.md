# Social Media Reach Analysis

**Presented by: Nakul Shelokar**

An end-to-end Social Media Reach Analysis portfolio project using Python, Power BI, data visualization, and machine learning.

## Features
- Data cleaning and missing-value handling
- KPI and engagement analysis
- Platform and content-type comparisons
- Python visualizations
- Power BI-ready Excel dataset and DAX measure sheet
- Random Forest reach prediction
- Streamlit dashboard

## Project Structure
- `data/` — raw and cleaned datasets
- `src/` — analysis and ML scripts
- `visuals/` — generated charts
- `powerbi/` — Power BI-ready workbook
- `presentation/` — project presentation
- `dashboard.py` — Streamlit dashboard
- `requirements.txt` — Python dependencies

## Run locally
```bash
pip install -r requirements.txt
python src/analysis.py
python src/predict_reach.py
streamlit run dashboard.py
```

> Dataset is synthetic and created for educational/portfolio purposes.
